package com.example.debezium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebeziumApplicationTests {

	@Test
	void contextLoads() {
	}

}
